This is the game folder for the distribution version of Katana-Clash. 
Double Click on the executable file named 'Katana-Clash', give it a few seconds
And the game will start.

### How to Run Katana Clash on macOS

1. Download the game ZIP file and extract it.
2. Open the "Katana-Clash.app" file.
3. If you see a security message saying "Katana-Clash cannot be opened because Apple cannot check it for malicious software," follow these steps:
   - Go to **System Preferences** → **Security & Privacy** → **General**.
   - At the bottom, click **Open Anyway**.
   - Confirm the dialog by clicking **Open**.
4. The game will now run.