This is the version for windows 10.
It should work upon running Katana-Clash.exe.
Note:
    At least on my machine, it is significantly slower than mac.
Windows might not like you downloading a random python executable
but i assure you there are no malicious lines of code. 