This is the version for windows 10.
It should work upon runing Katana-Clash.exe.
Note:
    At least on my machine, it is significantly slower than mac.